﻿using System;

namespace web_application_blazor.Models
{
    public class CalculationHistory
    {
        public int Id { get; set; }
        public string Expression { get; set; } = string.Empty;
        public string Result { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
