using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Security.Cryptography;
using System.Text.Json.Serialization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Security.Cryptography;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

var builder = WebApplication.CreateBuilder(args);

// Configure JWT settings
builder.Configuration["Jwt:Key"] = "VerySecretKeyForDevOnlyChangeThis!";
builder.Configuration["Jwt:Issuer"] = "MyBlazorApp";
builder.Configuration["Jwt:Audience"] = "MyBlazorAppUsers";

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddHttpContextAccessor();

// Add our lightweight user/activity services (file based)
builder.Services.AddSingleton<SimpleUserStore>();
builder.Services.AddSingleton<ActivityStore>();
builder.Services.AddSingleton<JwtService>();

// Configure authentication using JWT bearer (for API endpoints)
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    var key = Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]);
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidateAudience = true,
        ValidAudience = builder.Configuration["Jwt:Audience"],
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ValidateLifetime = true
    };
});

var app = builder.Build();

// Seed a demo user if none exists
var userStore = app.Services.GetRequiredService<SimpleUserStore>();
if (!userStore.HasUsers) {
    userStore.CreateUser("alice", "Password123!");
}

// Minimal API endpoints for auth and activity
app.MapPost("/api/auth/login", (LoginRequest req, SimpleUserStore users, JwtService jwt) =>
{
    var user = users.ValidateCredentials(req.Username, req.Password);
    if (user == null) return TypedResults.Unauthorized();
    var token = jwt.GenerateToken(user.Username);
    return Results.Ok(new { token, username = user.Username });
});

app.MapPost("/api/auth/change-password", (ChangePasswordRequest req, SimpleUserStore users) =>
{
    var ok = users.ChangePassword(req.Username, req.OldPassword, req.NewPassword);
    if (!ok) return Results.BadRequest(new { error = "Invalid username or password" });
    return Results.Ok();
});

app.MapPost("/api/activity/add", (ActivityRecord rec, Microsoft.AspNetCore.Http.HttpRequest request, ActivityStore store) =>
{
    // In a real app validate JWT. Here we accept username from payload.
    store.Add(rec);
    return Results.Ok();
});

app.MapGet("/api/activity/{username}", (string username, ActivityStore store) =>
{
    var list = store.GetForUser(username);
    return Results.Ok(list);
});

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();

// --- DTOs and lightweight services ---
public record LoginRequest(string Username, string Password);
public record ChangePasswordRequest(string Username, string OldPassword, string NewPassword);
public record ActivityRecord(string Username, DateTime Timestamp, string Input, string NumericResult, string WordsResult);

public class SimpleUser
{
    public string Username { get; set; }
    public byte[] PasswordHash { get; set; }
    public byte[] Salt { get; set; }
}

public class SimpleUserStore
{
    private readonly string _file = Path.Combine(AppContext.BaseDirectory, "users.json");
    private List<SimpleUser> _users = new();

    public SimpleUserStore()
    {
        if (File.Exists(_file))
        {
            var txt = File.ReadAllText(_file);
            try { _users = System.Text.Json.JsonSerializer.Deserialize<List<SimpleUser>>(txt) ?? new(); } catch { _users = new(); }
        }
    }

    public bool HasUsers => _users.Count > 0;

    public SimpleUser? ValidateCredentials(string username, string password)
    {
        var u = _users.FirstOrDefault(x => x.Username == username);
        if (u == null) return null;
        using var rdb = new Rfc2898DeriveBytes(password, u.Salt, 100000, HashAlgorithmName.SHA256);
        var hash = rdb.GetBytes(32);
        if (hash.SequenceEqual(u.PasswordHash)) return u;
        return null;
    }

    public void CreateUser(string username, string password)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        using var rdb = new Rfc2898DeriveBytes(password, salt, 100000, HashAlgorithmName.SHA256);
        var hash = rdb.GetBytes(32);
        var u = new SimpleUser { Username = username, PasswordHash = hash, Salt = salt };
        _users.Add(u);
        Save();
    }

    public bool ChangePassword(string username, string oldPassword, string newPassword)
    {
        var u = _users.FirstOrDefault(x => x.Username == username);
        if (u == null) return false;
        using var rdb = new Rfc2898DeriveBytes(oldPassword, u.Salt, 100000, HashAlgorithmName.SHA256);
        if (!rdb.GetBytes(32).SequenceEqual(u.PasswordHash)) return false;
        var newSalt = RandomNumberGenerator.GetBytes(16);
        using var rdb2 = new Rfc2898DeriveBytes(newPassword, newSalt, 100000, HashAlgorithmName.SHA256);
        u.Salt = newSalt;
        u.PasswordHash = rdb2.GetBytes(32);
        Save();
        return true;
    }

    private void Save()
    {
        var txt = System.Text.Json.JsonSerializer.Serialize(_users);
        File.WriteAllText(_file, txt);
    }
}

public class ActivityStore
{
    private readonly string _file = Path.Combine(AppContext.BaseDirectory, "activities.json");
    private List<ActivityRecord> _items = new();

    public ActivityStore()
    {
        if (File.Exists(_file))
        {
            var txt = File.ReadAllText(_file);
            try { _items = System.Text.Json.JsonSerializer.Deserialize<List<ActivityRecord>>(txt) ?? new(); } catch { _items = new(); }
        }
    }

    public void Add(ActivityRecord r) { _items.Add(r); Save(); }
    public List<ActivityRecord> GetForUser(string username) => _items.Where(x => x.Username == username).OrderByDescending(x => x.Timestamp).ToList();
    private void Save() { File.WriteAllText(_file, System.Text.Json.JsonSerializer.Serialize(_items)); }
}

public class JwtService
{
    private readonly IConfiguration _cfg;
    public JwtService(IConfiguration cfg) => _cfg = cfg;
    public string GenerateToken(string username)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_cfg["Jwt:Key"]));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var claims = new[] { new System.Security.Claims.Claim("sub", username) };
        var token = new System.IdentityModel.Tokens.Jwt.JwtSecurityToken(
            issuer: _cfg["Jwt:Issuer"],
            audience: _cfg["Jwt:Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddHours(6),
            signingCredentials: creds);
        return new System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler().WriteToken(token);
    }
}
