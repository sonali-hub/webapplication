window.blazorHelpers = {
  scrollTo: function(el) {
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }
};