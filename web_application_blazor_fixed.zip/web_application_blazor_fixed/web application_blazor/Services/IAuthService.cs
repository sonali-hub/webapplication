﻿using System.Threading.Tasks;

public interface IAuthService
{
    Task<string> Register(string username, string password);
    Task<string> Login(string username, string password);
    Task ChangePassword(int userId, string newPassword);
    Task<string> GetUserByToken(string token);
}
