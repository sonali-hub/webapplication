﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace web_application_blazor.Services
{
    public class AuthService : IAuthService
    {
        private readonly Dictionary<int, string> _users = new Dictionary<int, string>();
        private readonly Dictionary<string, int> _tokens = new Dictionary<string, int>();
        private int _userIdCounter = 1;

        // Register user
        public Task<string> Register(string username, string password)
        {
            // For demo purposes, we just store username + password as a fake token
            int userId = _userIdCounter++;
            _users[userId] = $"{username}:{password}";

            string token = Guid.NewGuid().ToString();
            _tokens[token] = userId;

            return Task.FromResult(token);
        }

        // Login user
        public Task<string> Login(string username, string password)
        {
            foreach (var kvp in _users)
            {
                var stored = kvp.Value.Split(':');
                if (stored[0] == username && stored[1] == password)
                {
                    string token = Guid.NewGuid().ToString();
                    _tokens[token] = kvp.Key;
                    return Task.FromResult(token);
                }
            }
            return Task.FromResult<string>(null);
        }

        // Change password
        public Task ChangePassword(int userId, string newPassword)
        {
            if (_users.ContainsKey(userId))
            {
                var stored = _users[userId].Split(':');
                string username = stored[0];
                _users[userId] = $"{username}:{newPassword}";
            }
            return Task.CompletedTask;
        }

        // Get user from token
        public Task<string> GetUserByToken(string token)
        {
            if (_tokens.ContainsKey(token))
            {
                int userId = _tokens[token];
                return Task.FromResult(_users[userId]);
            }
            return Task.FromResult<string>(null);
        }
    }
}
